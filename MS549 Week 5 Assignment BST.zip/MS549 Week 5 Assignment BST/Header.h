#pragma once

#include <iostream>
#include <ctime>
#include <chrono>
#include <algorithm>

using namespace std;


//create a structure
struct treeNode //Not a BST class, just the node
{
	int item; //data, does not have to be int, but must be rankable
	treeNode* Lchild; //pointer to
	treeNode* Rchild; //pointer to
	//the basis of the structure in the BST
};

class BST //Don't need attributes, just need to add/remove, etc. Can include functions
{

	//define functions for the BST
public: //data private, methods public
	BST(); //constructor function
	bool add(int i); //return true/false whether someone can add to the BST
	bool remove(int i);
	void inOrder(); //print statement
	void inOrder(treeNode*);
	int max(); //find max value
	//void preOrder(treeNode* p);

	void timeTest();

private: //helper functions that cannot be used outside
	//void inOrder(treeNode*);
	bool remove(treeNode* n, treeNode* parent);
	treeNode* root; //pointer to the root tree node
};
