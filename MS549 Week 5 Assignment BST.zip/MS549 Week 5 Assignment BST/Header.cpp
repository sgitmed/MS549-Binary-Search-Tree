#include <iostream>
#include <ctime>
#include <chrono>
#include <algorithm>
#include "Header.h"
#include <string>

using namespace std;

BST::BST()
{
	root = NULL; //set the root to null, establishing a tree
}

bool BST::add(int i)
{
	treeNode* n = new treeNode();//pointer to a tree node is = to a new tree node
	//input data into the node
	n->item = i; //new item= integer
	//if empty
	if (root == NULL)
	{
		root = n;
		return true;
	}
	//if int already exists. P=present, assign to root so we can walk through tree and find out where it goes
	else
	{
		treeNode* p = root; //start at the top of the tree
		while (p != NULL)
		{
			//check to make sure there is not a duplicate
			if (i == p->item)//if input = value in tree, return false
			{
				return false;
			}
			//if not a duplicate, evaluate if less than or equal to
			//Less than root, left
			//Greater than root, right
			else if (i < p->item)
			{
				if (p->Lchild == NULL)
				{
					p->Lchild = n;
					return true;
				}
				//if there is a left child
				else
				{
					p = p->Lchild;
				}
			}
			//Greater than
			else
			{
				if (p->Rchild == NULL)
				{
					p->Rchild = n;
					return true;
				}
				else
				{
					p = p->Rchild;
				}
			}

		}

		return true;
	}
}
void BST::inOrder() //print statement
{
	inOrder(root);
}
void BST::inOrder(treeNode* n)
{
	//start going left to the bottom, then up to the right
	//see if n is null
	if (n == NULL)
	{
		return;
	}
	inOrder(n->Lchild);
	cout << n->item << " ";
	inOrder(n->Rchild);

}

int BST::max()
{
	// no value, return 
	if (root == NULL)
	{
		//assume -1 is not a valid value
		return -1;
	}
	else
	{
		//start a pointer at the root, navigate pointer to the right until it is null
		treeNode* p = root; //point at the top of the bst
		while (p->Rchild != NULL) //if we have not reached the end of the right tree
		{
			p = p->Rchild; //move to the right
		}
		return p->item; //return the maximum value
	}

}
//remove function.  Code provided by Dr. Coddington, explanations of code were provided by chatGPT and paraphrased for better understanding
bool BST::remove(treeNode* n, treeNode* parent)
{
	//checks to see if n is a leaf node
	if (n->Lchild == NULL && n->Rchild == NULL)
	{
		if (parent != NULL) //ensure node is not the root
		{
			//if node is the left child of its parent, set the left child to null
			if (parent->Lchild == n)
				parent->Lchild = NULL;
			//if n is the right child, set child to null
			else
				parent->Rchild = NULL;
		}
		//delete the only node in the tree (root)
		else
			root = NULL;

		delete n;
	}
	else if (n->Lchild != NULL && n->Rchild == NULL) //for nodes with only left childs
	{
		if (parent != NULL) //if node is not the root
		{
			if (parent->Lchild == n)
			{
				//update the child's pointer to point to the parent node
				parent->Lchild = n->Lchild;
			}
			else
			{
				//right child's parent now equals the (moved) left node
				parent->Rchild = n->Lchild;
			}
		}
		else //deleting root with left child
		{
			root = n->Lchild; //update the root
		}
		delete n;
	}
	else if (n->Rchild != NULL && n->Lchild == NULL) //Node to be deleted has right child
	{
		if (parent != NULL)
		{
			//update the child pointers
			if (parent->Lchild == n)
			{

				parent->Lchild = n->Rchild;
			}
			else
			{
				parent->Rchild = n->Rchild;
			}
		}
		else //update root
		{
			root = n->Rchild;
		}
		delete n; //delete
	}
	else //node has r and l children
	{
		//find the rightmost node in left subtree
		//q = pointer to the rightmost node
		//qparent = pointer to the parent of q
		treeNode* q = n->Lchild, * qparent = n;
		//traverse to the rightmost child of n.Lchild
		while (q->Rchild != NULL)
		{
			qparent = q;
			q = q->Rchild;
		}
		n->item = q->item; //replace the nodes value
		return remove(q, qparent); //remove the node
	}
	return true;
}

//removal function with find. Code provided by Dr. Coddington, explanations of code were provided by chatGPT and paraphrased for better understanding
bool BST::remove(int i)
{
	//variable declarations
	//pointer to root of the BST
	//pointer to keep track of the parents
	treeNode* p = root, * parent = NULL;
	while (p != NULL) //traverse the tree
	{
		//compare node value with i
		//if value = i, remove the node
		if (p->item == i)

			return remove(p, parent); //removal function
		//update the parent pointer
		parent = p; //update the parent node

		//move to the left or right child based on value of i
		if (i < p->item)
		{
			p = p->Lchild;
		}
		else
		{
			p = p->Rchild;
		}
	}
	return false;

}
//creating the function for the testing portions of the assignment
void BST::timeTest()
{
	//create a new instance of a BST tree
	BST bstTimed;
	int random;
	//creating arrays of input sizes
	const int sizes[] = { 100,1000, 10000, 100000 };
	//loop through the different array sizes
	for (int size : sizes)
	{
		//reset the bst
		bstTimed = BST();
		random = 1 + rand() % size;
		//measure insertion
		cout << "Inserting " << size << " nodes." << endl;
		//start the clock
		auto start = chrono::high_resolution_clock::now();
		for (int i = 0; i < size; i++)
		{
			bstTimed.add(random);
		}
		auto end = chrono::high_resolution_clock::now(); // End time
		cout << "BST Insert of " << size << ": " << chrono::duration_cast<chrono::microseconds>(end - start).count() << " microseconds\n";
	}

}