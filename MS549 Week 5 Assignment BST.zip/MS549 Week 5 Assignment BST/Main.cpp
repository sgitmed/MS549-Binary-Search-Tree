#include <iostream>
#include <ctime>
#include <chrono>
#include <algorithm>
#include "Header.h"
#include <string>

using namespace std;

int main()
{
	//create a BST
	BST bst;
	//create random numbers to insert into bst
	int random; //random variable
	int maximum;
	for (int i = 0; i < 100; i++)  //start at 0, continue until i =99, increment
	{
		random = 1 + rand() % 100; //give a random number between 1 and 100
		cout << "Intserting " << random << endl;
		bst.add(random); //add random number to bst
	}
	bst.inOrder();
	cout << endl;
	maximum = bst.max(); //call the max function and assign the result to a local variable
	cout << "Max Value = " << maximum << endl;
	cout << "Remove 22: ";
	bst.remove(22);
	bst.inOrder();

	bst.timeTest();



	return 0;
}